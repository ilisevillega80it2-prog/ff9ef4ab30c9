// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("lock bench"); }
int main(){
  announce();
  return lionss_run_workload("lock-bench");
}
