// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("uml diagrams"); }
int main(){
  announce();
  return lionss_run_workload("uml-diagrams");
}
