// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("linux x86 64"); }
int main(){
  announce();
  return lionss_run_workload("linux-x86-64");
}
