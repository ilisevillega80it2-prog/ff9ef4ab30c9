// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("capability audit\n", stdout);
  return lionss_run_workload("capability-audit");
}
