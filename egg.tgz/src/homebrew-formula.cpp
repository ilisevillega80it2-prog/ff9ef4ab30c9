// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("homebrew formula\n", stdout);
  return lionss_run_workload("homebrew-formula");
}
