// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("dogfood\n", stdout);
  return lionss_run_workload("dogfood");
}
